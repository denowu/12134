exports.handler = async (event, context) => {
  const ip = event.headers['x-forwarded-for'] || event.headers['client-ip'] || 'Unknown';
  const user = context.clientContext && context.clientContext.user && context.clientContext.user.email;
  let logs = [];
  try {
    logs = require('../../ip-logs.json');
  } catch (e) {}
  logs.push({ user: user || 'anonymous', ip, time: new Date().toISOString() });
  const fs = require('fs');
  fs.writeFileSync('./ip-logs.json', JSON.stringify(logs, null, 2));
  return {
    statusCode: 200,
    body: JSON.stringify({ message: 'IP logged', ip, user })
  };
};
