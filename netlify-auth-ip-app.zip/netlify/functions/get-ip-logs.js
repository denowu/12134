exports.handler = async (event, context) => {
  let logs = [];
  try {
    logs = require('../../ip-logs.json');
  } catch (e) {}
  return {
    statusCode: 200,
    body: JSON.stringify({ logs })
  };
};
